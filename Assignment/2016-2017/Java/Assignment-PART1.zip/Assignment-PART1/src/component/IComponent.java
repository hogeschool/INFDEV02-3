package component;

public interface IComponent extends Updateable, Drawable {

}
