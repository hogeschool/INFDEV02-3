package stateMachine;

public interface IAction {
    void run();
}
